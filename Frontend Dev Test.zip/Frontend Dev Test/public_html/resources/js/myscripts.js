var modalEle = document.querySelector(".modal");
var modalImage = document.querySelector(".modal-content");
Array.from(document.querySelectorAll("#image-1")).forEach(item => {
    item.addEventListener("click", event => {
        modalEle.style.display = "block";
        modalImage.src = event.target.src;
    });
});
document.querySelector(".close").addEventListener("click", () => {
    modalEle.style.display = "none";
});

